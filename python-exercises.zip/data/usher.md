In the greenest of our valleys,
By good angels tenanted,
Once fair and stately palace --
Radiant palace --reared its head.
In the monarch Thought's dominion --
It stood there!
Never seraph spread a pinion
Over fabric half so fair.
