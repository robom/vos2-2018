semordnilap palindromes stressed desserts
plane aviator landscape