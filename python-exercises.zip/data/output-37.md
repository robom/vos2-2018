1 O! nothing earthly save the ray
2 (Thrown back from flowers) of Beauty's eye,