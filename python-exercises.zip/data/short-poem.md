O! nothing earthly save the ray
(Thrown back from flowers) of Beauty's eye,