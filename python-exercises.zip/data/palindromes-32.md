Satan, oscillate my metallic sonatas
Was it a rat I saw?
Rise to vote sir
Sample line